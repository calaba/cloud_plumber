
XATTR_BASE = "user.filer-base"
XATTR_REPO = "user.filer-repo"