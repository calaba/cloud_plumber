
module Main where

import qualified Filer.Main

main :: IO ()
main = Filer.Main.main
