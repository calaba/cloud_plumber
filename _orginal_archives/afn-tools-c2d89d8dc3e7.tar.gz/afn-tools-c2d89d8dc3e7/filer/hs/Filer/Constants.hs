
module Filer.Constants where

xattrBase = "user.filer-base"
xattrRepo = "user.filer-repo"
