
module Filer.Main where

main :: IO ()
main = do
    putStrLn "Filer version control"
    putStrLn "http://hg.opengroove.org/afn"
    putStrLn "More to come soon."
