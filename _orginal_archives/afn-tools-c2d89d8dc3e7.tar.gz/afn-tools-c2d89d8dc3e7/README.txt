UPDATE: The AFN repository, which was formerly moved from git to hg, is being split up into separate repositories for its constituent projects and moved back to git as of September 2013. See http://github.com/javawizard for the new projects.

The old README is as follows:

The AFN Project is a collection of libraries and tools initially created by Alexander Boyd and with contributions from others.

See meta/README.txt for more information.

