""" jzbot
This plugin adds the buzz protocol, which allows connecting to Google Buzz
"""