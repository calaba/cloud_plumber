package test;

import jw.jzbot.JZBot;

public class Test12
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        System.out.println(JZBot.datasize(3l));
    }
    
}
