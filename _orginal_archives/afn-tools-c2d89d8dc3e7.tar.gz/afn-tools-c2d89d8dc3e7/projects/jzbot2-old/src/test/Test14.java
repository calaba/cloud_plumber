package test;

import jw.jzbot.fact.functions.text.RestrictFunction;

public class Test14
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        System.out.println(new RestrictFunction().getHelp(null));
    }
    
}
