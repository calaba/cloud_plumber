package test;

import jw.jzbot.eval.jeval.Expression;

public class Test06
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        System.out.println(new Expression("2^16").eval());
    }
    
}
