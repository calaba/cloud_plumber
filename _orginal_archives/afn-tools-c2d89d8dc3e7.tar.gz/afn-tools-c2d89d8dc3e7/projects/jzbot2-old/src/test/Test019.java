package test;

import jw.jzbot.Command;

public class Test019
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        System.out.println(Command.class);
    }
    
}
