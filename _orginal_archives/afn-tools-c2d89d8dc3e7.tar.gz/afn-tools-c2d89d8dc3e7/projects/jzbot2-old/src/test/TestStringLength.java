package test;

public class TestStringLength
{
    public static void main(String[] args)
    {
        System.out.println("".length());
    }
}
