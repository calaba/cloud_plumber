package test;

public class Test10
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        System.out.println("local.misc.bzfrag".matches("^[0-9a-z\\-\\.]*$"));
    }
    
}
