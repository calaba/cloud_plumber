This folder contains a variety of documents relating to how JZBot works. These
are primarily intended for the use of JZBot developers, but anyone may read them.

If two files appear to contradict each other, you should view the JZBot repository
history and see which of the two contradicting texts was added last. This one is
the one that should be used.  