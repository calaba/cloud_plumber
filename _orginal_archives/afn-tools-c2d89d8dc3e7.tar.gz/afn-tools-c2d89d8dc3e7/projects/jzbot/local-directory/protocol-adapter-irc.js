/**
 * A protocol adapter for the IRC protocol.
 */
protocols.IRC = function()
{
	
};

protocols.IRC.prototype.