jzbot.load("persistent-store.js");
jzbot.load("sql.js");
Global.protocols = new Object();
jzbot.load("protocol-adapter-irc.js");
jzbot.load("protocol-adapter-bzflag.js");