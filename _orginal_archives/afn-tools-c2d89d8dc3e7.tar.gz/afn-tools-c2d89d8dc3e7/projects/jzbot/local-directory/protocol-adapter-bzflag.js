/**
 * A protocol adapter for the BZFlag protocol. 
 */
