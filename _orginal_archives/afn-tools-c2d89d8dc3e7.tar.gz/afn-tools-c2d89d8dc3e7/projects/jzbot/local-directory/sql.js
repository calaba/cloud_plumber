/**
 * This file defines the SQL statements used throughout jzbot.
 */
Global.sql = new Object();
sql.