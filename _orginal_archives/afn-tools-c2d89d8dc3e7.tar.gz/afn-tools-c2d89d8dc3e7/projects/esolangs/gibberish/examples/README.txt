This folder contains a number of Gibberish examples. All examples are provided with a short description at the top of the file about what they do. All descriptions have the text "]ev" at the end of them; this is not part of any of the example programs; it's simply how a comment is written in Gibberish. 

To run an example, open a terminal pointed to the main gibberish folder, and type:

gibberish examples/examplefile.g

where examplefile.g is the name of the file to run.
