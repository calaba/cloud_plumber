package tests;

import org.opengroove.sixjet.controller.ui.frames.MainFrame;

public class Test04
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        MainFrame.main(args);
    }
    
}
