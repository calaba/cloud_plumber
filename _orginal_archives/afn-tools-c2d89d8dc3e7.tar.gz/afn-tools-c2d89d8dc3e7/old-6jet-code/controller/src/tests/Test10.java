package tests;

public class Test10
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        System.out.println("started");
        for (int i = 0; i < 1000000000; i++)
            ;
        System.out.println("done");
    }
    
}
