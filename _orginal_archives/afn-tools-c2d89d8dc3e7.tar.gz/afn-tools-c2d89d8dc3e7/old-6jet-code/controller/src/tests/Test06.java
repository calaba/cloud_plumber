package tests;

import org.opengroove.sixjet.controller.SixjetController;

public class Test06
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        SixjetController.main(args);
    }
    
}
