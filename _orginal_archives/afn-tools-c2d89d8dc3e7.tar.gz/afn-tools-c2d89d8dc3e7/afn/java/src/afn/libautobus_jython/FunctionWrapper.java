package afn.libautobus_jython;

import org.python.core.PyObject;

public class FunctionWrapper
{
    public Object invoke(Object... args)
    {
        return null;
    }
    
    public PyObject invoke_py(Object[] args)
    {
        return null;
    }
    
    public Object invoke_later(Object... args)
    {
        return null;
    }
    
    public PyObject invoke_later_py(Object[] args)
    {
        return null;
    }
}
