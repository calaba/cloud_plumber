package afn.libautobus_jython;

public interface ObjectListener<T>
{
    public void changed(T value);
}
