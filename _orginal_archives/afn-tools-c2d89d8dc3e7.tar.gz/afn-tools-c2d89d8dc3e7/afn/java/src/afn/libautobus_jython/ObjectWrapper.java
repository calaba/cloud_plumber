package afn.libautobus_jython;

public class ObjectWrapper
{
    
}
