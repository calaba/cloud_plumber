package afn.libautobus_jython;

public class InterfaceWrapper
{
    public String name;
    
    public FunctionWrapper get_function(String name)
    {
        return null;
    }
}
