package afn.parcon;

import java.util.ArrayList;

public class ThenList<E> extends ArrayList<E> {
}
