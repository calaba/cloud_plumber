package afn.libautobus;

public class TimeoutException extends RuntimeException
{
    
}
