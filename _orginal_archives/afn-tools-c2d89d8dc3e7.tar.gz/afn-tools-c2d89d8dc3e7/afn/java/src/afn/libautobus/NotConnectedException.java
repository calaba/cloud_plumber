package afn.libautobus;

public class NotConnectedException extends RuntimeException
{
    
}
