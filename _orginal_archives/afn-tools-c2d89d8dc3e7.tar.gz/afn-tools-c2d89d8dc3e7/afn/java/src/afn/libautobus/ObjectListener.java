package afn.libautobus;

public interface ObjectListener<E>
{
    public void changed(E value);
}
