package afntest;

import afn.ui.UpButton;

public class UpButton01
{
    
    /**
     * @param args
     */
    public static void main(String[] args)
    {
        UpButton button = new UpButton();
        button.setText("");
    }
    
}
