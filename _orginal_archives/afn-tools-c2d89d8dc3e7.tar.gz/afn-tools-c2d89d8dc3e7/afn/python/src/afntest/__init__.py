__doc__ = """\
This module contains a bunch of random modules I'm using to test out AFN stuff.
"""