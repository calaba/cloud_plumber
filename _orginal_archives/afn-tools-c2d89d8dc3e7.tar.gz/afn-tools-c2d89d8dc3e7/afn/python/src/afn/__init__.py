"""
A collection of various utilities written as part of AFN
(github.com/javawizard/afn).
"""