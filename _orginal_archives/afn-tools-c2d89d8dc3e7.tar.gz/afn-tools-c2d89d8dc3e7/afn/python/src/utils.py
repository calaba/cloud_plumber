"""
This module has been moved to afn.utils. You may still use this module (it now
contains only one line, namely "from afn.utils import *", so everything's still
usable from here), but you should probably use afn.utils in any future projects
you're writing that might otherwise make use of this module.
"""

from afn.utils import * #@UnusedWildImport








