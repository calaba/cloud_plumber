
"""
This module provides a simple wiki backed by a git repository.

It's a really simple wiki for now. It doesn't even require a password to log
in; you simply enter your name and email address as you want them to show up in
the commit log, or leave them blank to use the name and email address
configured in the repository or on your machine.
"""