
from socket import socket as Socket, error as SocketError

def main():
    print "Interconnect has yet to actually be written. Sorry."