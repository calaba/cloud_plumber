
static_typing = True
check_types_in_production_evaluation = True
