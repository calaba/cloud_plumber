
namespace jpath
{
    void downref(Object* object);
    void upref(Object* object);
}
