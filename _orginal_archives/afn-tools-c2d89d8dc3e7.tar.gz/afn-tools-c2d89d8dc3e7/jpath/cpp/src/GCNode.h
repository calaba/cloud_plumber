#include "Node.h"

namespace jpath
{
    class Object;
    typedef Node<Object*> GCNode;
}
