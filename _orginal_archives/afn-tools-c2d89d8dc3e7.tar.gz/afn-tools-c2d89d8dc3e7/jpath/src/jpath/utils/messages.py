
JPATH_INTERNAL_ERROR_MESSAGE = ("This is a JPath internal error; report this "
        "to the JPath developers and they'll get it fixed as soon as "
        "possible. (one of them is alex@opengroove.org in case you don't "
        "have any other information about how to get in touch with them.)")
