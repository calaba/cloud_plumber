
import jpath.data as data
from copy import copy as shallow_copy

