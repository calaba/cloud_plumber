This was an older version of JPath that I was attempting to write. I've since abandoned this particular version of JPath, and development is now going on at new-projects/jpathdb.
