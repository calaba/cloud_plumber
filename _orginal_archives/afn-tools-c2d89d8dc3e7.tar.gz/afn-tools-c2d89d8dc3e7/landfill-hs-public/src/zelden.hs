
import qualified Zelden.Server as ZS

main = ZS.main
