package jw.supertunnel.client;

public class Response
{
    public int status;
    public byte[] data;
}
