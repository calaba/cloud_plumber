package jw.supertunnel;

public class Constants
{
    public static final int httpNoConnection = 431;
    public static final int httpTooManyConnections = 432;
    public static final int httpTooMuchData = 413;
    public static final int httpLengthMismatch = 433;
}
